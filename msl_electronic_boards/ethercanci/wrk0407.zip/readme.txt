REVISION HISTORY

Current Versions

Library: 2.51.0.0
Monitor: 2.40.1.1
Documentation WRK: 4.01
Documentation WDK: 4.03

Drivers:

Win2K:
CPC-PP/ECO: 2.23
CPC-PP:     2.36
CPC-XT:     2.01
CPC-PCI:    2.22
CPC-Card:   1.23
CPC-USB:    1.79.0.1

WinXP (Vista):
CPC-PP/ECO: 2.23
CPC-PP:     2.36
CPC-XT:     2.01
CPC-PCI:    2.22
CPC-Card:   1.23
CPC-USB:    1.79.0.1

If you update from a version prior to 3.70 please read the installation hints
for the 3.70 version (see section wdk0370 below).

wdk0407 (21.10.08) (Patch 1):
- Monitor     - Bugfix: Crashed on Windows 2000 when closing the channel

                new version 2.40.1.1 (Win2k/XP)

wdk0407 (29.09.08):
- CPC-CARD    - CPC_WaitForEvent supported

                new version now 1.23 (Win2k/XP)

- CPC-PCI     - Support new CPC-PCI v2 with up to 4 CAN channels
              - CPC_WaitForEvent supported
              - Bugfix: Unable to clear mode bits

                new version now 2.22 (Win2k/XP)

- CPC-XT/104  - CPC_WaitForEvent supported
              - Bugfix: Opening channel with wrong interrupt caused any
                        further open attempts to fail even selected
                        interrupt is available
              - Bugfix: If the application crashed, channel is left open

                new version now 2.01 (Win2k/XP)

- CPC-USB     - Bugfix: Crash when accessing non-existant event objects

                new version now 1.79.0.1 (Win2k/XP)

- Library     - CPC_WaitForEvent support (C, C# (.NET), Delphi)
              - EtherCAN supports CPC_WaitForEvent as well

                new version 2.51.0.0 (Win2k/XP)

wdk0406 (08.07.08):
- General     - New improved installer
                Doesn't support Windows 98 and Windows NT anymore
                (still available on request).
              - CPC-XTI/104I no longer supported (still available on request)

- CPC-USB     - Bugfix: Don't stop polling if buffer is full
              - CPC_WaitForEvent supported

                new version now 1.79 (Win2k/XP)

wdk0404 (30.09.07):
- CPC-XT      - Supports CPC-104M

                new version now 2.00 (WinNT/2k/XP)


wdk0403 (27.11.06):
- CAN Monitor - When opening a CAN channel make sure CPC_Control is sent to interface

                new version now 2.40.0.1

- Library   - Corrected wrong return value when opening a USB-Channel which
              is already open

              new version now 2.50.1.3

- CPC-USB   - Bugfix: When a channel is closed and quickly reopened this may
              crash the system
			
            - Reset device to known state on Open/Close (clear command queue and
              set CAN-Controller to BusOff)

              new version now 1.78 (Win9X/2k/XP)

wdk0402 (11.04.06):
- General:  - This is a bugfix release for the CPC-USB driver on WinXP

- CPC-USB:  - rebuild WinXP driver

              new version now 1.77.0.2 (XP)


wdk0401 (27.02.06):
- General:  - This release is just a maintainance release to add support
              for the CPC-USB/ARM7 CAN/USB interface

- CPC-USB:  - added support for CPC-USB/ARM7
            - support for CPC_ClearCMDQueue()

              new version now 1.77 (Win9X/2k/XP)

wdk0400 (03.06.05):
- General:  - The Development Kit can now be obtained in 2 different
              versions:
              1. general license: can be used with several interfaces
                 one time purchasing fee
              2. single license: bundled to the purchased interface,
                 needs a license file to work properly

- Library   - the DLL is now dynamically loaded upon runtime. It is
              mandatory to link the library file 'cpcwinxx.lib' to
              the application:
              cpcwinmg.lib: general license, Microsoft compiler
              cpcwinms.lib: single license,  Microsoft compiler
              cpcwinbg.lib: general license, Borland compiler
              cpcwinbs.lib: single license,  Borland compiler
            - support CPC-XTS under Win9x

- CPC-USB:  - stability improvements (disconnecting, high loads)
            - bug has been fixed that cause the bulk in transfer to
              stop

              new version now 1.76 (Win9X/2k/XP)

- CPC-PCI:  - the sending strategy can now be controlled by a registry
              entry (default: wait for 'transmission complete').
            - the bus state is now evaluated and also returns the
              receive and transmit error counter values
            - CPC_CANExit is supported
            - Hardware and Software overruns are now supported

              new version now 2.25 (Win9X)
                              2.28 (WinNT)
                              2.18 (WinNT/2K/XP)

- CPC-Card: - the sending strategy can now be controlled by a registry
              entry (default: wait for 'transmission complete').
            - the bus state is now evaluated and also returns the
              receive and transmit error counter values
            - CPC_CANExit is supported
            - Hardware and Software overruns are now supported

              new version now 1.22 (Win2K/XP)

- CPC-ECO:  - the sending strategy can now be controlled by a registry
              entry (default: wait for 'transmission complete').
            - the bus state is now evaluated and also returns the
              receive and transmit error counter values
            - CPC_CANExit is supported
            - Hardware and Software overruns are now supported

              new version now 2.13 (Win9X)
                              2.23 (WinNT/2K/XP)

- CPC-XTS:  - the sending strategy can now be controlled by a registry
              entry (default: wait for 'transmission complete').
            - the bus state is now evaluated and also returns the
              receive and transmit error counter values
            - CPC_CANExit is supported
            - Hardware and Software overruns are now supported
            - Version for Win9X added

              new version now 1.14 (WinNT/2K/XP)
                              1.01 (Win9X)


wdk0380 (26.10.04):
- Develop:  - the Development Kit now has Borland Delphi support

wdk0376 (12.10.04):
- CPC-USB:  - bugfix: the SJA2M16C parameter conversion routine caused
              the PC to crash
              new version now 1.70 
- Library   - bugfix: in case of unplugging CPC-USB upon operation
              the library wouldn't close the channel correctly and
              release the resources
              new version now 2.48 

wdk0375 (23.09.04):
- Installer - fixed some problems with improper installs
- CPC-USB:  - bugfix: The channel would not be properly closed if
              an application was exited before it received a message
              from the interface
              new version now 1.65 

wdk0374 (30.08.04):
- CPC-ECO:  - implemented CAN state events
              new version see below
- CPC-USB:  - fixed a bug that would stop working if a physical
              error occured on the USB
            - fixed a bug that would crash the PC in case of
              removing while in full action
              new version now 1.63
- CPC-XTI:  - complete review. Each board handled as own device
              new version now 2.00
- CPC-XT:   - implemented CAN state events
              new version now 2.00
- CPC-Card: - implemented CAN state events
              new version now 1.15
- CPC-LIB:  - internal changes within cpcwin.dll
              new version now 2.47


wdk0373 (16.12.03):
- fixed a bug within the CPC-USB driver that would return a false number
  of messages from the CPC message buffer
  new version now 1.47


wdk0372 (17.11.03):
- changed the order of exported functions to keep compatibility with older
  version of the library
  new version now 2.44



wdk0371 (12.11.03):
- fixed a bug within the library that would not recognize CPC-XTI interfaces
  on WindowsXP. 
  new version now 2.41
- fixed a bug within the driver for CPC-XTI that would transmit the CAN parameters
  to the PC in a wrong order
  new version now is 1.11


wdk0370 (25.10.03):
- complete review of all drivers. New versions are listed below
- Added the driver for CPC-XT (for WinNT/2K/XP, Philips CAN controllers only)

IMPORTANT:
This version is a major modification of the Development Kit. It is therefore
necessary to deinstall prior versions of the kit.
Before deinstalling an older version, first deinstall CPC interfaces listed 
within the device manager (CPC-PCI, CPC-Card, CPC-USB). After deinstallation,
look for the 'inf' folder of your Windows directory (it may be hidden). Within 
this folder search all 'inf' files for the following strings:
cpcpci
cpcusb
cpccrd
Delete all 'inf/pnf' combinations containing the above strings. The found files
should begin with the letters 'oemX' where X is a number.
You are now ready to install the new version of the Development kit.


wdk0361 (04.06.03):
- added Win98 driver for the CPC-USB interface
  new version now is 1.30
- updated the documentation
  new version now is 3.60

wdk0360 (28.05.03):
- added Win2K/XP driver for the CPC-USB interface
  new version now is 1.30
- fixed a bug in the library that would not allow to send partial frames
  to EtherCAN over TCP/IP
  new version now is 2.30

wdk0357 (12.02.03):
- bugfixes and performance enhancement of the CPC-PP driver for Win9X
  new version now is 2.30
- bugfixes and performance enhancement of the CPC-PP driver for WinNT/2K/XP
  new version now is 2.30
- modified the libary
  new version now is 2.10

wdk0356 (11.12.02):
- fixed a bug in the CPC-PP driver (WinNT/2K/XP) that would cause a crash if
  a CPC-PP with firmware 1.1 was connected but not powered
  driver version is now 2.23
- fixed a bug in the CPC-PCI driver (Win2K/XP) that would assign the same resources
  to multiple boards and thus only allow to use the first boards
  driver version is now 2.12
- multiple instances of the proCANtool CAN-Monitor can now be started to use
  CAN channels on different interfaces at the same time
  monitor version is now 2.20

wdk0355 (29.11.02):
- added proCANtool CAN-Monitor application
- fixed a bug in the CPC-PCI driver (Win9X) that would crash the PC
  if multiple PCI board are installed

wdk0351 (05.11.02):
- added support for multiple CPC-PCI boards (Win9X/NT/2K/XP)

wdk0350 (26.09.02):
- fixed a bug within the library that wouldn't allow multiple 
  applications to access different channels on one interface
- added Win2K/XP driver for the CPC-Card
- added WinNT/2K/XP driver for the CPC-XTI and CPC-104I

wdk03412 (01.07.2002):
- fixed a bug in the CPC-PP NT/2000/XP driver
  the computer would crash if no CPC-PP is connected

wdk03411 (07.06.2002):
- fixed a bug in the installation script. The CPC-PP 
  and CPC-PP/Eco drivers wouldn't install on Win2K/XP 
  because of a missing file
